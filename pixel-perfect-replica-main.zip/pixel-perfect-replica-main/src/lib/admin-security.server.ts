import { createHash, timingSafeEqual } from 'node:crypto';
import { getRequest, setResponseHeader, useSession } from '@tanstack/react-start/server';
export function digest(value: string) { return createHash('sha256').update(value).digest('hex'); }
export function passwordMatches(input: string, expected: string) {
  return timingSafeEqual(Buffer.from(digest(input)), Buffer.from(digest(expected)));
}
export function authorizedSession(version: unknown, expected: string | undefined) {
  return Boolean(expected && typeof version === 'string' && passwordMatches(version, digest(expected)));
}
export async function adminSession() {
  const secret = process.env['SESSION_SECRET'];
  if (!secret) throw new Error('تعذر بدء جلسة الإدارة');
  setResponseHeader('Cache-Control', 'no-store');
  return useSession<{ version?: string }>({ password: secret, name: 'mahdi-admin', maxAge: 60 * 60 * 8, cookie: { httpOnly: true, secure: true, sameSite: 'strict', path: '/' } });
}
export function requireSameOrigin() {
  const request = getRequest();
  const origin = request.headers.get('origin');
  if (!origin || new URL(origin).host !== new URL(request.url).host) throw new Error('طلب غير مسموح');
}
export async function requireAdmin() {
  requireSameOrigin();
  const session = await adminSession();
  if (!authorizedSession(session.data.version, process.env['ADMIN_PASSWORD'])) throw new Error('يرجى تسجيل الدخول أولاً');
}
